# DotnetConference2016

Contenido que demuestra cómo realizar una única autenticación y tener acceso a los recursos de la infraestructura de Azure, como API Graph, Sharepoint Online, etc. Por otro lado, se muestra la integración de una aplicación WebApi como sistema backend desplegado on premise, y funcionando bajo la misma autenticación y autorización.

El código del backend extiende la autorización para realizarla basada en grupos de seguridad. Para que dicha gestión sea posible, debe modificarse en Azure el manifest de la aplicación cliente, ya que los grupos de seguridad a los que pertenece un usuario estarán establecidos en los claims contenidos en el token de autenticación.

Básicamente, los pasos son:

1) Registra tu aplicación backend (WebApi en este caso) dentro de Azure AD. Al crear la aplicación en Visual Studio, directamente podrá crearte la entrada en Azure si seleccionas Autenticación de organización, además de agregarte las referencias, código y configuración necesaria.

2) Registra tu aplicación cliente. Basta con crear en Azure AD una aplicación nativa, utilizar el client ID asignado por Azure y especificar el Return Uri a cualquiera (aunque no exista). Ese client Id y la Return Uri deben utilizarse para la autenticación con ADAL.

3) En Azure, para tu aplicación nativa, da permisos para acceder a la aplicación backend. Ya tendrás SSO entre ambas.

4) Modifica el manifiesto en Azure de la aplicación cliente para que groupMembershipClaims tenga el valor "SecurityGroup" para poder utilizar los grupos de usuario como seguridad de acceso a recursos.

Lo demás, es código fuente disponible en Git.

Después de la #DotnetConference 2016, subiré la presentación con más detalles.

Saludos!!!

Juan Cuello Rubio

