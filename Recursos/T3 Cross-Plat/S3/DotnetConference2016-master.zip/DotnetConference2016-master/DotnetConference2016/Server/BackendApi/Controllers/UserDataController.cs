﻿using BackendApi.Models;
using BackendApi.Security;
using System.Web.Http;

namespace BackendApi.Controllers
{
    [Authorize]
    public class UserDataController : ApiController
    {  

        public IHttpActionResult Get()
        {
            UserData userData = new UserData
            {
                UserName = User.Identity.Name,
                GivenName = SecurityHelper.GetGivenName(User),
                SurName = SecurityHelper.GetSurname(User),
                IsAuthenticated = User.Identity.IsAuthenticated,
                Groups = string.Join(",", SecurityHelper.GetUserGroupNames(User))
            };

            return Ok(userData);
        }

        [AuthorizeRole(Roles = SecurityGroups.Managers)]
        public IHttpActionResult Get(string username)
        {
            UserData userData = new UserData
            {
                UserName = username,
                GivenName = "Name of " + username,
                SurName = "Surname of " + username,
                IsAuthenticated = false,
                Groups = "Other groups"
            };

            return Ok(userData);
        }
    }
}
