﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Claims;
using System.Security.Principal;


namespace BackendApi.Security
{
    public static class SecurityHelper
    {
        public static bool IsUserInRole(IPrincipal principal, string role)
        {
            ClaimsPrincipal claimsPrincipal = principal as ClaimsPrincipal;

            string[] userGroups = claimsPrincipal.Claims.Where(c => c.Type == "groups").Select(v => v.Value).ToArray();
            return userGroups.Any(c => c == role);
        }

        public static string GetGivenName(IPrincipal principal)
        {
            ClaimsPrincipal claimsPrincipal = principal as ClaimsPrincipal;

            var claim = claimsPrincipal.Claims.FirstOrDefault(c => c.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname");
            if (claim != null)
            {
                return claim.Value;
            }
            return null;
        }

        public static string GetSurname(IPrincipal principal)
        {
            ClaimsPrincipal claimsPrincipal = principal as ClaimsPrincipal;

            var claim = claimsPrincipal.Claims.FirstOrDefault(c => c.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname");
            if (claim != null)
            {
                return claim.Value;
            }
            return null;
        }

        public static string[] GetUserGroupSids(IPrincipal principal)
        {
            ClaimsPrincipal claimsPrincipal = principal as ClaimsPrincipal;
            string[] userGroups = claimsPrincipal.Claims.Where(c => c.Type == "groups").Select(v => v.Value).ToArray();
            return userGroups;
        }

        public static string[] GetUserGroupNames(IPrincipal principal)
        {
            ClaimsPrincipal claimsPrincipal = principal as ClaimsPrincipal;
            List<string> userGroups = claimsPrincipal.Claims.Where(c => c.Type == "groups").Select(v => v.Value).ToList();

            var groupData = typeof(SecurityGroups)
                    .GetFields(BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy)
                    .Where(fi => fi.IsLiteral && !fi.IsInitOnly && userGroups.Contains(fi.GetRawConstantValue()))
                    .Select(v => v.Name).ToArray();

            return groupData;
        }

        public static bool IsUserInSomeRole(IPrincipal principal, string roles)
        {
            string[] specifiedRoles = roles.ToLower().Split(',').Select(v => v.Trim()).ToArray();

            foreach (string role in specifiedRoles)
            {
                bool isInRole = IsUserInRole(principal, role);
                if (isInRole)
                {
                    return true;
                }
            }
            return false;
        }
    }
}