﻿namespace BackendApi.Security
{
    public static class SecurityGroups
    {
        public const string Managers = "9f561c8e-65ff-4bd7-91d5-27e5e630644d";
        public const string Developers = "aacb2a22-142c-4bb9-8e93-8592ae91cef1";
    }
}