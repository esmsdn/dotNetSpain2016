﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace BackendApi.Security
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = true)]
    public class AuthorizeRoleAttribute : AuthorizationFilterAttribute
    {
        public string Roles { get; set; }

        public override Task OnAuthorizationAsync(HttpActionContext actionContext, CancellationToken cancellationToken)
        {
            var principal = actionContext.RequestContext.Principal as ClaimsPrincipal;

            if (!principal.Identity.IsAuthenticated)
            {
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized, "Unauthorized access to non-authenticated users");
                return Task.FromResult<object>(null);
            }

            bool isInRoles = true;

            if (!string.IsNullOrEmpty(Roles))
            {
                isInRoles = SecurityHelper.IsUserInSomeRole(principal, Roles);
            }

            if (!isInRoles)
            {
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized,
                                                            string.Format("Unauthorized access: Operation to resource {0} not allowed for the user {1}. Allowed groups: {2}",
                                                                            actionContext.Request.RequestUri.AbsoluteUri,
                                                                            principal.Identity.Name,
                                                                            Roles));
                return Task.FromResult<object>(null);
            }

            //OK
            return Task.FromResult<object>(null);
        }

    }
}