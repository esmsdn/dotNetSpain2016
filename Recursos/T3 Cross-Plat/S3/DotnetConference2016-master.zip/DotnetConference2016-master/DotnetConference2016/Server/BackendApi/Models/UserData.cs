﻿namespace BackendApi.Models
{
    public class UserData
    {
        public string UserName { get; set; }
        public bool IsAuthenticated { get; set; }
        public string GivenName { get; set; }
        public string SurName { get; set; }
        public string Groups { get; set; }
    }
}