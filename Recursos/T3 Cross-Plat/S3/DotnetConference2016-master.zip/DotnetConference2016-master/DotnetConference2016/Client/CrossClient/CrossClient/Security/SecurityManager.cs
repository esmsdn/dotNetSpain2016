﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Threading.Tasks;

namespace CrossClient.Security
{
    public class SecurityManager : ISecurityManager
    {
        private readonly IAuthenticator _authenticator;

        public SecurityManager(IAuthenticator authenticator)
        {
            _authenticator = authenticator;
        }

        public bool IsUserAuthenticated()
        {
            TokenCacheItem item = GetCurrentAuthTicket();
            return (item != null && item.ExpiresOn < DateTime.Now);
        }

        public TokenCacheItem GetCurrentAuthTicket()
        {
            TokenCacheItem item = _authenticator.GetUserInfo(SecurityConstants.AzureAuthority);
            return item;
        }

        public async Task<AuthenticationResult> Authenticate()
        {
            return await _authenticator.Authenticate(SecurityConstants.AzureAuthority, 
                                                        SecurityConstants.BackendResourceId, 
                                                        SecurityConstants.AzureClientId, 
                                                        SecurityConstants.AzureReturnUri);
        }
    }
}
