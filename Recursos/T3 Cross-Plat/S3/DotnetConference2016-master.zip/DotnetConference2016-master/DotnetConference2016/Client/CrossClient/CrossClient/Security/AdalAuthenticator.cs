﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace CrossClient.Security
{
    public class AdalAuthenticator : IAuthenticator
    {
        public async Task<AuthenticationResult> Authenticate(string authority, string resourceId, string clientId, string returnUri)
        {
            var authContext = new AuthenticationContext(authority);
            if (authContext.TokenCache.ReadItems().Any(c => c.Authority == authority))
            {
                authContext = new AuthenticationContext(authContext.TokenCache.ReadItems().First().Authority);
            }

            var uri = new Uri(returnUri);
            var platformParams = GetPlatformParameters();
            var authResult = await authContext.AcquireTokenAsync(resourceId, clientId, uri, platformParams);
            return authResult;
        }

        protected virtual IPlatformParameters GetPlatformParameters()
        {
            throw new NotSupportedException("Platform parameters must be specified");
        }

        public TokenCacheItem GetUserInfo(string authority)
        {            
            var authContext = new AuthenticationContext(authority);
            var items = authContext.TokenCache.ReadItems();
            if (items.Any())
            {
                return items.First();
            }
            return null;
        }
    }
}
