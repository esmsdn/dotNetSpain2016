﻿using CrossClient.Security;
using System.Windows.Input;
using Xamarin.Forms;
using System.Threading.Tasks;
using CrossClient.Services.Registration;

namespace CrossClient.ViewModels
{
    public class LoginViewModel : BaseViewModel
    {
        private readonly ISecurityManager _securityManager;
        private readonly IResolver _resolver;

        private ICommand _loginCommand;

        public ICommand LoginCommand
        {
            get
            {
                _loginCommand = _loginCommand ?? new Command(async () => await Login());
                return _loginCommand;
            }
        }

        private async Task Login()
        {
            if (!_securityManager.IsUserAuthenticated())
            {
                await _securityManager.Authenticate();
            }

            MainViewModel mainViewMdel = _resolver.Resolve<MainViewModel>();
            mainViewMdel.Navigate();
        }

        public LoginViewModel(ISecurityManager securityManager, IResolver resolver)
        {
            _securityManager = securityManager;
            _resolver = resolver;
        }

        public void Navigate()
        {

        }

    }
}
