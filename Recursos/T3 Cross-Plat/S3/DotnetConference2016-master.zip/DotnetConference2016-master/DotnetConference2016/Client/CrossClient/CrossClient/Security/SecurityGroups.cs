﻿namespace CrossClient.Security
{
    public class SecurityGroups
    {
        public const string Developers = "Developers";
        public const string Managers = "Managers";
    }
}
