﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Threading.Tasks;

namespace CrossClient.Security
{
    public interface ISecurityManager
    {
        bool IsUserAuthenticated();
        TokenCacheItem GetCurrentAuthTicket();
        Task<AuthenticationResult> Authenticate();
    }
}
