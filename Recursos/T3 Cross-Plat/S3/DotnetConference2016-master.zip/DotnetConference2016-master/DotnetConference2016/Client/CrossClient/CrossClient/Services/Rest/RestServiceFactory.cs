﻿using CrossClient.Services.Factory;

namespace CrossClient.Services.Rest
{
    public class RestServiceFactory : IRestServiceFactory
    {
        private readonly IHttpClientFactory _clientFactory;

        public RestServiceFactory(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        public IRestClientService GetBackendClient()
        {
            return new RestClientService(_clientFactory, Security.SecurityConstants.BackendResourceId, Security.SecurityConstants.BackendResourceUri);
        }

        public IRestClientService GetSharepointClient()
        {
            return new RestClientService(_clientFactory, Security.SecurityConstants.SharepointResourceId, Security.SecurityConstants.SharepointResourceUri);
        }

        public IRestClientService GetGraphClient()
        {
            return new RestClientService(_clientFactory, Security.SecurityConstants.AzureGraphResourceId, Security.SecurityConstants.AzureGraphResourceUri);
        }
    }
}
