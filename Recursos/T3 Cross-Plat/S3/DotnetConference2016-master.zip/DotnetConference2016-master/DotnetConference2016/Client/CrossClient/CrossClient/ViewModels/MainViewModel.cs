﻿using CrossClient.Models;
using CrossClient.Security;
using CrossClient.Services.Rest;
using CrossClient.Views;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using System;

namespace CrossClient.ViewModels
{
    public class MainViewModel : BaseViewModel
    {
        private readonly IRestServiceFactory _restServiceFactory;

        MainView view;

        private UserData _userData;

        public UserData UserInfo
        {
            get
            {
                return _userData;
            }
            set
            {
                _userData = value;
                OnPropertyChanged();
            }
        }

        private string _graphData;

        public string GraphData
        {
            get
            {
                return _graphData;
            }
            set
            {
                _graphData = value;
                OnPropertyChanged();
            }
        }

        private string _spData;

        public string SharePointData
        {
            get
            {
                return _spData;
            }
            set
            {
                _spData = value;
                OnPropertyChanged();
            }
        }


        private ICommand _requestAdminData;

        public ICommand RequestAdminData
        {
            get
            {
                _requestAdminData = _requestAdminData ?? new Command(async () => await RequestAdminDataFunction());
                return _requestAdminData;
            }
        }

        private async Task RequestAdminDataFunction()
        {
            try
            {
                UserInfo = await _restServiceFactory.GetBackendClient().GetAsync<UserData>("api/userdata/dev1");
                GraphData = string.Empty;
                SharePointData = string.Empty;
            }
            catch (Exception e)
            {
                await view.DisplayAlert("UPS!", e.Message, "Ok");
            }

        }

        public MainViewModel(IRestServiceFactory restServiceFactory)
        {
            _restServiceFactory = restServiceFactory;
        }

        private async Task LoadData()
        {
            try
            {
                //CALL TO BACKEND
                UserInfo = await _restServiceFactory.GetBackendClient().GetAsync<UserData>("api/userdata/");
                //CALL TO MICROSOFT GRAPH                        
                //https://graph.microsoft.io/en-us/docs
                GraphData = await _restServiceFactory.GetGraphClient().GetAsync("me");
                //CALL TO SHAREPOINT ONLINE
                SharePointData = await _restServiceFactory.GetSharepointClient().GetAsync("sites/testsite/_api/Web?$select=Title");

            }
            catch (Exception e)
            {
                await view.DisplayAlert("UPS!", e.Message, "Ok");
            }
        }

        public void Navigate()
        {
            view = new MainView();
            view.BindingContext = this;
            App.Current.MainPage.Navigation.PushModalAsync(view);
            LoadData();
        }
    }
}
