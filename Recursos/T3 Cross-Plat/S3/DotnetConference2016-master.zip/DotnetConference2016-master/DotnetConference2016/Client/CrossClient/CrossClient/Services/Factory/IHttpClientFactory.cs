﻿using System.Net.Http;
using System.Threading.Tasks;

namespace CrossClient.Services.Factory
{
    public interface IHttpClientFactory
    {
        Task<HttpClient> Create(string resourceId, string resourceUri);
        Task<HttpClient> CreateBackendClient();
        Task<HttpClient> CreateGraphClient();
        Task<HttpClient> Create();
    }
}
