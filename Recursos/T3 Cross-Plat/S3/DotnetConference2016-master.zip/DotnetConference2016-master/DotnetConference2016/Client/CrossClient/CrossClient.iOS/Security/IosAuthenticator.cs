﻿using CrossClient.iOS.Security;
using CrossClient.Security;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using UIKit;

[assembly: Xamarin.Forms.Dependency(typeof(IosAuthenticator))]

namespace CrossClient.iOS.Security
{
    public class IosAuthenticator : AdalAuthenticator
    {
        protected override IPlatformParameters GetPlatformParameters()
        {
            var controller = UIApplication.SharedApplication.KeyWindow.RootViewController;
            return new PlatformParameters(controller);
        }
    }
}
