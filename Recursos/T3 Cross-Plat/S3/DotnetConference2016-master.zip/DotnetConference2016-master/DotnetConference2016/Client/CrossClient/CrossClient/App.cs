﻿using CrossClient.Services.Registration;
using CrossClient.ViewModels;
using CrossClient.Views;
using Xamarin.Forms;

namespace CrossClient
{
    public class App : Application
    {
        public App()
        {

            LoginView loginVew = new LoginView();
            loginVew.BindingContext = Container.Instance.Value.Get<LoginViewModel>();
            // The root page of your application
            MainPage = new NavigationPage(loginVew);

        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
