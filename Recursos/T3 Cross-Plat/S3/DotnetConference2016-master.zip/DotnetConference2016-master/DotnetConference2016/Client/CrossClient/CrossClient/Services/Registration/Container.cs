﻿using CrossClient.Security;
using CrossClient.Services.Factory;
using CrossClient.Services.Rest;
using CrossClient.ViewModels;
using Microsoft.Practices.Unity;
using System;

namespace CrossClient.Services.Registration
{
    public class Container
    {
        public static Lazy<Container> Instance = new Lazy<Container>(() => new Container(), true);

        private readonly UnityContainer unityContainer = new UnityContainer();

        private Container()
        {
            unityContainer.RegisterInstance<IResolver>(new Resolver(unityContainer));
        }


        public Container RegisterCommonServices()
        {
            unityContainer.RegisterType<IAuthenticator, AdalAuthenticator>();
            unityContainer.RegisterType<ISecurityManager, SecurityManager>();
            unityContainer.RegisterType<IHttpClientFactory, HttpClientFactory>();
            unityContainer.RegisterType<IRestServiceFactory, RestServiceFactory>();

            //viewmodels
            unityContainer.RegisterType<LoginViewModel>();
            unityContainer.RegisterType<MainViewModel>();

            return this;
        }

        public T Get<T>()
        {
            return unityContainer.Resolve<T>();
        }

        public Container Register<T, TImpl>() where TImpl : T
        {
            unityContainer.RegisterType<T, TImpl>(new TransientLifetimeManager());
            return this;
        }
        
    }
}
