﻿using System.Threading.Tasks;

namespace CrossClient.Services.Rest
{
    public interface IRestClientService
    {
        Task<string> GetAsync(string resource);
        Task DeleteAsync(string url);
        Task<string> PostAsync(string url, string body);
        Task PutAsync(string url, string body);
        Task<TResponse> GetAsync<TResponse>(string resource);
        Task<TResponse> PostAsync<TResponse, T>(string url, T entity);
        Task PutAsync<T>(string url, T entity);
        T DeserializeJSon<T>(string data);
    }
}
