using Android.App;
using CrossClient.Droid.Security;
using CrossClient.Security;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Xamarin.Forms;

[assembly: Xamarin.Forms.Dependency(typeof(AndroidAdalAuthenticator))]

namespace CrossClient.Droid.Security
{
    public class AndroidAdalAuthenticator : AdalAuthenticator
    {
        protected override IPlatformParameters GetPlatformParameters()
        {
            return new PlatformParameters((Activity)Forms.Context);
        }
    }
}