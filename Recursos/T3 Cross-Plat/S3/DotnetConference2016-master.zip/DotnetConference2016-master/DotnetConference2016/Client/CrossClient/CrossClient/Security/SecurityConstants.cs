﻿
namespace CrossClient.Security
{
    public class SecurityConstants
    {
        public const string AzureClientId = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        public const string AzureAuthority = "https://login.windows.net/juandotnet.onmicrosoft.com";
        public const string AzureReturnUri = "http://crossclient";
        public const string BackendResourceId = "https://juandotnet.onmicrosoft.com/BackendApi";
        public const string BackendResourceUri = "https://pcjuan/backendapi/";

        public const string AzureGraphResourceUri = "https://graph.microsoft.com/v1.0/";
        public const string AzureGraphResourceId = "https://graph.microsoft.com";

        public const string SharepointResourceUri = "https://juandotnet.sharepoint.com/";
        public const string SharepointResourceId = "https://juandotnet.sharepoint.com";
    }
}
