﻿namespace CrossClient.Services.Rest
{
    public interface IRestServiceFactory
    {
        IRestClientService GetBackendClient();
        IRestClientService GetSharepointClient();
        IRestClientService GetGraphClient();
    }
}
