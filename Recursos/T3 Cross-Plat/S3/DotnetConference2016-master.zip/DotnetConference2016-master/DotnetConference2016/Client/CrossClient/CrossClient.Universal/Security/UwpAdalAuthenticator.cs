﻿using CrossClient.Security;
using CrossClient.Universal.Security;
using Microsoft.IdentityModel.Clients.ActiveDirectory;

[assembly:Xamarin.Forms.Dependency(typeof(UwpAdalAuthenticator))]

namespace CrossClient.Universal.Security
{
    public class UwpAdalAuthenticator : AdalAuthenticator
    {
        protected override IPlatformParameters GetPlatformParameters()
        {
            return new PlatformParameters(PromptBehavior.Always, true);
        }
    }
}
