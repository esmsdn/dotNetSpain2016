﻿using Microsoft.Practices.Unity;

namespace CrossClient.Services.Registration
{
    public class Resolver: IResolver
    {
        private readonly IUnityContainer _container;

        public Resolver(IUnityContainer container)
        {
            _container = container;
        }

        public T Resolve<T>()
        {
            return _container.Resolve<T>();
        }
    }
}
