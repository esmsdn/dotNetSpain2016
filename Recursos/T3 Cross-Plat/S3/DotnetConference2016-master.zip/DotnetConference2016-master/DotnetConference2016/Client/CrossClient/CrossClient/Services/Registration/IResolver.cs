﻿namespace CrossClient.Services.Registration
{
    public interface IResolver
    {
        T Resolve<T>();
    }
}
