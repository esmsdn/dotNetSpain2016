﻿using CrossClient.Security;
using CrossClient.Services.Factory;
using System.Net.Http;
using Windows.Security.Cryptography.Certificates;
using Windows.Web.Http.Filters;

namespace CrossClient.Universal.Services
{
    public class UwpHttpClientFactory : HttpClientFactory
    {
        public UwpHttpClientFactory(IAuthenticator authenticator) : base(authenticator)
        {            
        }

        protected override HttpClient CreateClient()
        {
            var filter = new HttpBaseProtocolFilter();
            filter.IgnorableServerCertificateErrors.Add(ChainValidationResult.Untrusted);
            var client = new HttpClient(new WinRtHttpClientHandler(filter));
            return client;
        }
    }
}
