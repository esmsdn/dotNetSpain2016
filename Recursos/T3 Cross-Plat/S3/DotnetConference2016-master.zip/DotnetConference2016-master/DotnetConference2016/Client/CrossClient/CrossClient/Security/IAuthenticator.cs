﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Threading.Tasks;

namespace CrossClient.Security
{
    public interface IAuthenticator
    {
        Task<AuthenticationResult> Authenticate(string authority, string resourceId, string clientId, string returnUri);
        TokenCacheItem GetUserInfo(string authority);
    }
}
