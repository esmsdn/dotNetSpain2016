﻿using CrossClient.Security;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace CrossClient.Services.Factory
{
    public class HttpClientFactory : IHttpClientFactory
    {
        private readonly IAuthenticator _authenticator;

        public HttpClientFactory(IAuthenticator authenticator)
        {
            _authenticator = authenticator;
        }

        protected virtual HttpClient CreateClient()
        {
            return new HttpClient();
        }

        public async Task<HttpClient> Create(string resourceId, string resourceUri)
        {
            var result = await _authenticator.Authenticate(SecurityConstants.AzureAuthority, resourceId, SecurityConstants.AzureClientId, SecurityConstants.AzureReturnUri);
            HttpClient client = CreateClient();
            client.BaseAddress = new Uri(resourceUri);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(result.AccessTokenType, result.AccessToken);
            return client;
        }

        public async Task<HttpClient> CreateBackendClient()
        {
            return await Create(SecurityConstants.BackendResourceId, SecurityConstants.BackendResourceUri);
        }

        public async Task<HttpClient> CreateGraphClient()
        {
            return await Create(SecurityConstants.AzureGraphResourceId, SecurityConstants.AzureGraphResourceUri);
        }

        public async Task<HttpClient> Create()
        {
            return await CreateBackendClient();
        }
    }
}
