﻿using CrossClient.Services.Factory;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CrossClient.Services.Rest
{
    public class RestClientService : IRestClientService
    {
        private readonly IHttpClientFactory _clientFactory;
        private readonly string _resourceId;
        private readonly string _resourceUri;

        public RestClientService(IHttpClientFactory clientFactory, string resourceId, string resourceUri)
        {
            _clientFactory = clientFactory;
            _resourceId = resourceId;
            _resourceUri = resourceUri;
        }

        private StringContent LoadPostContent(string body)
        {
            StringContent res = new StringContent(body, Encoding.UTF8, "application/json");
            return res;
        }

        public async Task<TResponse> GetAsync<TResponse>(string resource)
        {
            string result = await GetAsync(resource);
            return DeserializeJSon<TResponse>(result);
        }

        public async Task<string> GetAsync(string resource)
        {
            var data = "";
            try
            {
                using (HttpClient client = await _clientFactory.Create(_resourceId, _resourceUri))
                {
                    var response = await client.GetAsync(resource);
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        data = await response.Content.ReadAsStringAsync();
                    }
                    else if (response.IsSuccessStatusCode)
                    {
                        data = await response.Content.ReadAsStringAsync();
                    }
                    else
                    {
                        if (response.Content != null)
                        {
                            data = await response.Content.ReadAsStringAsync();
                        }
                        throw new Exception(data);
                    }
                }
                return data;

            }
            catch (Exception e)
            {
                string a = e.Message;
                throw;
            }
        }

        private async Task<string> PostAsync(string url, StringContent postContent)
        {
            var data = "";
            using (HttpClient client = await _clientFactory.Create(_resourceId, _resourceUri))
            {
                HttpResponseMessage response;
                response = await client.PostAsync(string.Format("{0}", url), postContent);

                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    data = await response.Content.ReadAsStringAsync();
                }
                else
                {
                    throw new Exception("Error post");
                }
            }
            return data;
        }

        private async Task<string> Post(string url, StringContent postContent)
        {
            var data = "";
            using (HttpClient client = await _clientFactory.Create(_resourceId, _resourceUri))
            {

                HttpResponseMessage response;
                response = await client.PostAsync(string.Format("{0}", url), postContent);

                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    data = await response.Content.ReadAsStringAsync();
                }
                else
                {
                    throw new Exception("Error post");
                }
            }
            return data;
        }

        public async Task<string> PostAsync(string url, string body)
        {
            StringContent postContent = LoadPostContent(body);
            return await Post(url, postContent);
        }

        private async Task Put(string url, StringContent postContent)
        {
            using (HttpClient client = await _clientFactory.Create(_resourceId, _resourceUri))
            {
                HttpResponseMessage response;
                response = await client.PutAsync(string.Format("{0}", url), postContent);

                if (response.StatusCode != System.Net.HttpStatusCode.OK)
                {
                    throw new Exception("Error put");
                }
            }
        }

        public async Task PutAsync(string url, string body)
        {
            StringContent postContent = LoadPostContent(body);
            await Put(url, postContent);
        }

        private async Task Delete(string url)
        {
            using (HttpClient client = await _clientFactory.Create(_resourceId, _resourceUri))
            {
                HttpResponseMessage response = await client.DeleteAsync(string.Format("{0}", url));

                if (response.StatusCode != System.Net.HttpStatusCode.OK)
                {
                    throw new Exception("Error delete");
                }
            }
        }

        public async Task DeleteAsync(string url)
        {
            await Delete(url);
        }

        public T DeserializeJSon<T>(string data)
        {
            return (!string.IsNullOrEmpty(data))
                ? JsonConvert.DeserializeObject<T>(data)
                : default(T);
        }

        public async Task<TResponse> PostAsync<TResponse, T>(string url, T entity)
        {
            string entry = JsonConvert.SerializeObject(entity);
            string result = await PostAsync(url, entry);
            return DeserializeJSon<TResponse>(result);
        }

        public async Task PutAsync<T>(string url, T entity)
        {
            string entry = JsonConvert.SerializeObject(entity);
            await PutAsync(url, entry);
        }
    }
}
