# Atención
Los archivos de configuración con client ids y secret ids and sido eliminados por seguridad.
Deberás reemplazar esos datos por tus valores, así como los dominios de Azure utilizado.

