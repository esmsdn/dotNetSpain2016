# dotNet Spain Conference 2016

Samples used during my speech *Deep dive into background tasks in the Universal Windows Platform* at dotNetSpain Conference 2016 in Madrid

[https://www.desarrollaconmicrosoft.com/Dotnetspain2016](https://www.desarrollaconmicrosoft.com/Dotnetspain2016)