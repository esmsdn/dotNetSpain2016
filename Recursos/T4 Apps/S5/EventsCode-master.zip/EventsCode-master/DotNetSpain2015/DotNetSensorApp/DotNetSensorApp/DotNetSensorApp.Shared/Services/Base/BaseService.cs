﻿using DotNetSensorApp.ViewModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace DotNetSensorApp.Services.Base
{
    public class BaseService : SimpleViewModelBase
    {
    }
}