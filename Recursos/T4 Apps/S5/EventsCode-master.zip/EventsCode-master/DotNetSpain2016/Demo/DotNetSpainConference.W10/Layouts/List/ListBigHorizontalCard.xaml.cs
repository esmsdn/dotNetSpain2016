namespace DotNetSpainConference.Layouts.List
{
    public sealed partial class ListBigHorizontalCard : ListLayoutBase
    {
        public ListBigHorizontalCard()
        {
            this.InitializeComponent();
        }
    }
}
