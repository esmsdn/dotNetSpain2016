using AppStudio.Uwp.Controls;
using Windows.UI.Xaml.Controls;

namespace DotNetSpainConference.Layouts.Detail
{
    public sealed partial class MultiColumnDetailLayout : BaseDetailLayout
    {
        public MultiColumnDetailLayout()
        {
            InitializeComponent();
        }        
    }
}
