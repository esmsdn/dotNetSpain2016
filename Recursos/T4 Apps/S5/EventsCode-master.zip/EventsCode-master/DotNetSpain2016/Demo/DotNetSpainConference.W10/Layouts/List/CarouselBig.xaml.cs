namespace DotNetSpainConference.Layouts.List
{
    public sealed partial class CarouselBig : ListLayoutBase
    {
        public CarouselBig()
        {
            this.InitializeComponent();
        }
    }
}
