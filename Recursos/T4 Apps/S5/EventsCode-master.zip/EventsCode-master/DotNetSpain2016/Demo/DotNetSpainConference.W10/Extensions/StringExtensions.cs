using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetSpainConference
{
    public static class StringExtensions
    {
        public static string SafeType(this string s)
        {
            return s;
        }
    }
}
