using System;
using AppStudio.Uwp.Controls;
using Windows.UI.Xaml.Controls;

namespace DotNetSpainConference.Layouts.Detail
{
    public sealed partial class TextDetailLayout : BaseDetailLayout
    {
        public TextDetailLayout()
        {
            InitializeComponent();
        }
    }
}
