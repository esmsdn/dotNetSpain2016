namespace DotNetSpainConference.ViewModels
{
    public class AdvertisingViewModel
    {        
        public string Title { get; private set; }

        public AdvertisingViewModel()
        {
            Title = "Advertising";            
        }        
    }
}
