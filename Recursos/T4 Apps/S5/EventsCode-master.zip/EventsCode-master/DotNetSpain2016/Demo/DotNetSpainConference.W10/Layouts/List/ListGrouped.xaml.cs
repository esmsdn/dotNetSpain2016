using System.Collections.ObjectModel;
using Windows.UI.Xaml;
using AppStudio.Uwp.Controls;
using DotNetSpainConference.ViewModels;

namespace DotNetSpainConference.Layouts.List
{
    public sealed partial class ListGrouped : ListLayoutBase
    {
        public ListGrouped()
        {
            this.InitializeComponent();
        }
    }
}
