﻿namespace AppStudio.DataProviders.BingMaps
{
    public class BingMapsDataConfig
    {        
        public string DataSourceId { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public string Radius { get; set; }
        public string APIKey { get; set; }
    }
}
