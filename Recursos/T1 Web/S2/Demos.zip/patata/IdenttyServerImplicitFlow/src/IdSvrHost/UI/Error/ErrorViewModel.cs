﻿using IdentityServer4.Core.Models;

namespace IdSvrHost.UI.Error
{
    public class ErrorViewModel
    {
        public ErrorMessage Error { get; set; }
    }
}