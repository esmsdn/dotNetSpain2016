﻿using Authorization.Models;

namespace Authorization.ViewModels.Products
{
    public class EditProductViewModel
    {
        public Product Product { get; set; }

        public decimal Discount { get; set; }
    }
}
