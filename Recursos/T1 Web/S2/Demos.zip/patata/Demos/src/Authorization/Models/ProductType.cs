namespace Authorization.Models
{
    public enum ProductType
    {
        Standard = 0,
        Special
    }
}