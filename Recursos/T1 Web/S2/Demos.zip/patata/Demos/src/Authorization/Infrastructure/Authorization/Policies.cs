﻿namespace Authorization.Infrastructure.Authorization
{
    public static class Policies
    {
        public const string Sales = "Sales";

        public const string Over21 = "Over21Only";
    }
}
