﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PowerBI.Entities
{
    public class Datasets
    {
        public Dataset[] value { get; set; }
    }

    public class Dataset
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }

    public class NewDataset
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "tables")]
        public Table[] tables { get; set; }
    }

    public class Tables
    {
        public Table[] value { get; set; }
    }

    
    public class Column
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }
        
        [JsonProperty(PropertyName = "dataType")]
        public string DataType { get; set; }
    }

    public class Table
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "columns")]
        public Column[] columns { get; set; }
    }

    public class Groups
    {
        public Group[] value { get; set; }
    }

    public class Group
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }


}
