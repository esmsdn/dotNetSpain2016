﻿// Ejemplo basado en http://go.microsoft.com/fwlink/?LinkId=619280

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Newtonsoft.Json;
using PowerBI.Entities;
using PowerBIClient.Model;

namespace PowerBIClient
{
    class Program
    {   
        // Client app ID. 
        private static string clientID = "{ COMPLETA CON TU CLIENTID }";
        //RedirectUri you used when you registered your app.
        private static string redirectUri = "https://login.live.com/oauth20_desktop.srf";
        //Resource Uri for Power BI API
        private static string resourceUri = "https://analysis.windows.net/powerbi/api";
        //OAuth2 authority Uri
        private static string authority = "https://login.windows.net/common/oauth2/authorize";
        //Uri for Power BI datasets
        private static string datasetsUri = "https://api.powerbi.com/v1.0/myorg";

        // Install-Package Microsoft.IdentityModel.Clients.ActiveDirectory
        private static AuthenticationContext authContext = null;
        private static string token = String.Empty;

        private static string datasetName = "EventHubSimulate";
        private static string tableName = "Sound";

        static void Main(string[] args)
        {
            try
            {

                Console.WriteLine("Iniciando PowerBIClient. Presione Enter para iniciar...");
                Console.ReadLine();

                Console.WriteLine("Obteniendo  AccessToken...");
                string accessToken = AccessToken();
                if (string.IsNullOrEmpty(accessToken))
                {
                    Console.WriteLine("Error al obtener el Access Token.");
                    return;
                }


                #region " Crear DataSet "

                Console.WriteLine("Creando dataset...");
                // Validamos que exista el Dataset
                Datasets datasets = GetDataSets();
                var customDataset = datasets.value.Where(d => d.Name.Equals(datasetName)).FirstOrDefault();
                if(customDataset == null)
                {
                    CreateDataSets(new NewDataset()
                    {
                        Name = datasetName,
                        tables = new Table[] {
                                    new Table() {
                                        Name = tableName,
                                        columns = new Column[] {
                                             new Column() { Name = "ID", DataType = "string" },
                                            new Column() { Name = "db", DataType = "Int64" },
                                            new Column() { Name = "Updated", DataType = "DateTime" },
                                            new Column() { Name = "AvgDb", DataType = "Int64" },
                                            new Column() { Name = "Min", DataType = "Int64" },
                                            new Column() { Name = "Max", DataType = "Int64" }
                                        }
                                    }
                                }
                    });
                }

                Console.WriteLine("actualizando dataset...");
                UpdateSchema(customDataset.Id, new Table()
                {
                    Name = tableName,
                    columns = new Column[] {
                                            new Column() { Name = "ID", DataType = "string" },
                                            new Column() { Name = "db", DataType = "Int64" },
                                            new Column() { Name = "Updated", DataType = "DateTime" },
                                            new Column() { Name = "AvgDb", DataType = "Int64" },
                                            new Column() { Name = "Min", DataType = "Int64" },
                                            new Column() { Name = "Max", DataType = "Int64" }
                                        }
                });

                #endregion

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine("Proceos finalizado. Presione Enter para finalizar.");
            Console.ReadLine();
        }

        static string AccessToken()
        {
            if (token == String.Empty)
            {
                //Get Azure access token
                // Create an instance of TokenCache to cache the access token
                TokenCache TC = new TokenCache();
                // Create an instance of AuthenticationContext to acquire an Azure access token
                authContext = new AuthenticationContext(authority, TC);
                // Call AcquireToken to get an Azure token from Azure Active Directory token issuance endpoint
                token = authContext.AcquireToken(resourceUri, clientID, new Uri(redirectUri), PromptBehavior.RefreshSession).AccessToken;
            }
            else
            {
                // Get the token in the cache
                token = authContext.AcquireTokenSilent(resourceUri, clientID).AccessToken;
            }

            return token;
        }
        
        //Create a GET web request to list all datasets
        //The Get Datasets operation returns a JSON list of all Dataset objects that includes a name and id.
        //GET https://api.powerbi.com/v1.0/myorg/datasets
        //Get Dataset operation: https://msdn.microsoft.com/en-US/library/mt203567.aspx
        static Datasets GetDataSets()
        {
            
            Datasets result = null;
            try
            {
                HttpWebRequest request = System.Net.WebRequest.Create(String.Format("{0}/datasets", datasetsUri)) as System.Net.HttpWebRequest;
                request.KeepAlive = true;
                request.Method = "GET";
                request.ContentLength = 0;
                request.ContentType = "application/json";
                request.Headers.Add("Authorization", String.Format("Bearer {0}", AccessToken()));

                //Get HttpWebResponse from GET request
                string responseContent = string.Empty;
                using (HttpWebResponse httpResponse = request.GetResponse() as System.Net.HttpWebResponse)
                {
                    //Get StreamReader that holds the response stream
                    using (StreamReader reader = new System.IO.StreamReader(httpResponse.GetResponseStream()))
                    {
                        responseContent = reader.ReadToEnd();
                    }
                }

                result = JsonConvert.DeserializeObject<Datasets>(responseContent);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return result;
        }

        //Create a POST web request to list all datasets
        //The Get Datasets operation returns a JSON list of all Dataset objects that includes a name and id.
        //GET https://api.powerbi.com/v1.0/myorg/datasets
        //Get Dataset operation: https://msdn.microsoft.com/en-us/library/mt203562.aspx
        //{
        //    "name": "SalesMarketing","tables": 
        //        [{"name": "Product", "columns": 
        //            [{ "name": "ProductID", "dataType": "Int64"},
        //             { "name": "Name", "dataType": "string"},
        //             { "name": "Category", "dataType": "string"},
        //             { "name": "IsCompete", "dataType": "bool"},
        //             { "name": "ManufacturedOn", "dataType": "DateTime"}
        //            ]
        //          }
        //        ]
        //}
        static bool CreateDataSets(NewDataset newDataset)
        {

            bool result = false;
            try
            {
                HttpWebRequest request = System.Net.WebRequest.Create(String.Format("{0}/datasets", datasetsUri)) as System.Net.HttpWebRequest;
                request.KeepAlive = true;
                request.Method = "POST";
                request.ContentLength = 0;
                request.ContentType = "application/json";
                request.Headers.Add("Authorization", String.Format("Bearer {0}", AccessToken()));

                byte[] byteArray = System.Text.Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(newDataset));
                request.ContentLength = byteArray.Length;

                //Write JSON byte[] into a Stream
                using (Stream writer = request.GetRequestStream())
                {
                    writer.Write(byteArray, 0, byteArray.Length);
                }


                //Get HttpWebResponse from GET request
                string responseContent = string.Empty;
                using (HttpWebResponse httpResponse = request.GetResponse() as System.Net.HttpWebResponse)
                {
                    //Get StreamReader that holds the response stream
                    using (StreamReader reader = new System.IO.StreamReader(httpResponse.GetResponseStream()))
                    {
                        responseContent = reader.ReadToEnd();
                    }
                }

                result = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return result;
        }

        //{
        //  "name": "Product",
        //  "columns": [
        //    {
        //      "name": "ProductID",
        //      "dataType": "Int64"
        //    },
        //    {
        //      "name": "Name",
        //      "dataType": "string"
        //    }
        //  ]
        //}  
        static bool UpdateSchema(string datasetId, Table table)
        {
            bool result = false;
            try
            {
                HttpWebRequest request = System.Net.WebRequest.Create(String.Format("{0}/datasets/{1}/tables/{2}", datasetsUri, datasetId, table.Name)) as System.Net.HttpWebRequest;
                request.KeepAlive = true;
                request.Method = "PUT";
                request.ContentLength = 0;
                request.ContentType = "application/json";
                request.Headers.Add("Authorization", String.Format("Bearer {0}", AccessToken()));

                byte[] byteArray = System.Text.Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(table));
                request.ContentLength = byteArray.Length;

                //Write JSON byte[] into a Stream
                using (Stream writer = request.GetRequestStream())
                {
                    writer.Write(byteArray, 0, byteArray.Length);
                }


                //Get HttpWebResponse from GET request
                string responseContent = string.Empty;
                using (HttpWebResponse httpResponse = request.GetResponse() as System.Net.HttpWebResponse)
                {
                    //Get StreamReader that holds the response stream
                    using (StreamReader reader = new System.IO.StreamReader(httpResponse.GetResponseStream()))
                    {
                        responseContent = reader.ReadToEnd();
                    }
                }

                result = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return result;
        }

        //The Get Tables operation returns a JSON list of Tables for the specified Dataset.
        //GET https://api.powerbi.com/v1.0/myorg/datasets/{dataset_id}/tables
        //Get Tables operation: https://msdn.microsoft.com/en-US/library/mt203556.aspx
        static Tables GetTables(string datasetId)
        {
            Tables result = null;
            try
            {
                HttpWebRequest request = System.Net.WebRequest.Create(String.Format("{0}/datasets/{1}/tables", datasetsUri, datasetId)) as System.Net.HttpWebRequest;
                request.KeepAlive = true;
                request.Method = "GET";
                request.ContentLength = 0;
                request.ContentType = "application/json";
                request.Headers.Add("Authorization", String.Format("Bearer {0}", AccessToken()));

                //Get HttpWebResponse from GET request
                string responseContent = string.Empty;
                using (HttpWebResponse httpResponse = request.GetResponse() as System.Net.HttpWebResponse)
                {
                    //Get StreamReader that holds the response stream
                    using (StreamReader reader = new System.IO.StreamReader(httpResponse.GetResponseStream()))
                    {
                        responseContent = reader.ReadToEnd();
                    }
                }

                result = JsonConvert.DeserializeObject<Tables>(responseContent);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return result;
        }

        //The Add Rows operation adds Rows to a Table in a Dataset.
        //POST https://api.powerbi.com/v1.0/myorg/datasets/{dataset_id}/tables/{table_name}/rows
        //Add Rows operation: https://msdn.microsoft.com/en-US/library/mt203561.aspx
        //{"rows":
        //    [
        //        {"ProductID":1,"Name":"Adjustable Race","Category":"Components","IsCompete":true,"ManufacturedOn":"07/30/2014"},
        //        {"ProductID":2,"Name":"LL Crankarm","Category":"Components","IsCompete":true,"ManufacturedOn":"07/30/2014"},
        //        {"ProductID":3,"Name":"HL Mountain Frame - Silver","Category":"Bikes","IsCompete":true,"ManufacturedOn":"07/30/2014"}
        //    ]
        //}
        static bool AddRecords(string datasetId, string tableName, Products products)
        {
            bool result = false;
            try
            {
                HttpWebRequest request = System.Net.WebRequest.Create(String.Format("{0}/datasets/{1}/tables/{2}/rows", datasetsUri, datasetId, tableName)) as System.Net.HttpWebRequest;
                request.KeepAlive = true;
                request.Method = "POST";
                request.ContentLength = 0;
                request.ContentType = "application/json";
                request.Headers.Add("Authorization", String.Format("Bearer {0}", AccessToken()));

                byte[] byteArray = System.Text.Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(products));
                request.ContentLength = byteArray.Length;

                //Write JSON byte[] into a Stream
                using (Stream writer = request.GetRequestStream())
                {
                    writer.Write(byteArray, 0, byteArray.Length);
                }


                //Get HttpWebResponse from GET request
                string responseContent = string.Empty;
                using (HttpWebResponse httpResponse = request.GetResponse() as System.Net.HttpWebResponse)
                {
                    //Get StreamReader that holds the response stream
                    using (StreamReader reader = new System.IO.StreamReader(httpResponse.GetResponseStream()))
                    {
                        responseContent = reader.ReadToEnd();
                    }
                }

                result = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return result;
        }

        //The Delete Rows operation deletes Rows from a Table in a Dataset.
        //DELETE https://api.powerbi.com/v1.0/myorg/datasets/{dataset_id}/tables/{table_name}/rows
        //Delete Rows operation: https://msdn.microsoft.com/en-US/library/mt238041.aspx
        static bool CleanRecords(string datasetId, string tableName)
        {
            bool result = false;
            try
            {
                HttpWebRequest request = System.Net.WebRequest.Create(String.Format("{0}/datasets/{1}/tables/{2}/rows", datasetsUri, datasetId, tableName)) as System.Net.HttpWebRequest;
                request.KeepAlive = true;
                request.Method = "DELETE";
                request.ContentLength = 0;
                request.ContentType = "application/json";
                request.Headers.Add("Authorization", String.Format("Bearer {0}", AccessToken()));
                
                //Get HttpWebResponse from GET request
                string responseContent = string.Empty;
                using (HttpWebResponse httpResponse = request.GetResponse() as System.Net.HttpWebResponse)
                {
                    //Get StreamReader that holds the response stream
                    using (StreamReader reader = new System.IO.StreamReader(httpResponse.GetResponseStream()))
                    {
                        responseContent = reader.ReadToEnd();
                    }
                }

                result = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return result;
        }
    }
}
