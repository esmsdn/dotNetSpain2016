﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Newtonsoft.Json;
using PowerBI.Entities;
using PowerBIWeb.Models;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace PowerBIWeb.Controllers
{
    public class DashboardController : Controller
    {
        private static string datasetsUri = "https://api.powerbi.com/beta/myorg";
        AuthenticationResult authResult = null;

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            HttpSessionStateBase session = filterContext.HttpContext.Session;
            if (session.IsNewSession || Session["authResult"] == null)
            {
                var @params = new NameValueCollection
                {
                    //Azure AD will return an authorization code. 
                    //See the Redirect class to see how "code" is used to AcquireTokenByAuthorizationCode
                    {"response_type", "code"},

                    //Client ID is used by the application to identify themselves to the users that they are requesting permissions from. 
                    //You get the client id when you register your Azure app.
                    {"client_id", Properties.Settings.Default.ClientID},

                    //Resource uri to the Power BI resource to be authorized
                    {"resource", "https://analysis.windows.net/powerbi/api"},

                    //After user authenticates, Azure AD will redirect back to the web app
                    {"redirect_uri", "https://localhost:44300/gettoken"}
                };

                //Create sign-in query string
                var queryString = HttpUtility.ParseQueryString(string.Empty);
                queryString.Add(@params);

                //Redirect authority https://powerbi.microsoft.com/en-us/documentation/powerbi-developer-authenticate-a-web-app/
                //Authority Uri is an Azure resource that takes a client id to get an Access token
                //https://login.windows.net/common/oauth2/authorize
                //  ? response_type = code
                //  & client_id = 1861585d...9a79c296
                //  & resource = https://analysis.windows.net/powerbi/api
                //  &redirect_uri = http://localhost:13526/Redirect

                string authorityUri = "https://login.windows.net/common/oauth2/authorize/";
                var authUri = String.Format("{0}?{1}", authorityUri, queryString);
                filterContext.Result = Redirect(authUri);
            }
            else {
                authResult = (AuthenticationResult)Session["authResult"];
            }
        }


        // GET: Dashboard
        public ActionResult Index()
        {
            Dashboards dashboards = GetDashboards();
            var ds = dashboards.value.Where(d => d.Title.Equals("SoundDashboard")).FirstOrDefault();

            Tiles tiles = GetTiles(ds.Id);
            var tile = tiles.value.Where(t => t.Title.Equals("db")).FirstOrDefault();
           
            Reports reports = GetReports();
            var report = reports.value.Where(r => r.Name.Equals("Retail Analysis Sample")).FirstOrDefault();

            DashboardModel model = new DashboardModel()
            {
                AccessToken = authResult.AccessToken,
                Tile = new DashboardModel.TileModel()
                {
                    Id = tile.Id,
                    Title = tile.Title,
                    EmbedUrl = string.Concat(tile.EmbedUrl, "&width=722&height=500")
                },
                Report = new DashboardModel.ReportModel()
                {
                     Id = report.Id,
                     Title = report.Name,
                     WebUrl = report.WebUrl,
                     EmbedUrl = report.EmbedUrl
                }
            };

            return View(model);
        }

        private Dashboards GetDashboards()
        {

            Dashboards result = null;
            try
            {
                HttpWebRequest request = System.Net.WebRequest.Create(String.Format("{0}/dashboards", datasetsUri)) as System.Net.HttpWebRequest;
                request.KeepAlive = true;
                request.Method = "GET";
                request.ContentLength = 0;
                request.ContentType = "application/json";
                request.Headers.Add("Authorization", String.Format("Bearer {0}", authResult.AccessToken));

                //Get HttpWebResponse from GET request
                string responseContent = string.Empty;
                using (HttpWebResponse httpResponse = request.GetResponse() as System.Net.HttpWebResponse)
                {
                    //Get StreamReader that holds the response stream
                    using (StreamReader reader = new System.IO.StreamReader(httpResponse.GetResponseStream()))
                    {
                        responseContent = reader.ReadToEnd();
                    }
                }

                result = JsonConvert.DeserializeObject<Dashboards>(responseContent);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return result;
        }

        private Tiles GetTiles(string dashboardId)
        {

            Tiles result = null;
            try
            {
                HttpWebRequest request = System.Net.WebRequest.Create(String.Format("{0}/dashboards/{1}/tiles", datasetsUri, dashboardId)) as System.Net.HttpWebRequest;
                request.KeepAlive = true;
                request.Method = "GET";
                request.ContentLength = 0;
                request.ContentType = "application/json";
                request.Headers.Add("Authorization", String.Format("Bearer {0}", authResult.AccessToken));

                //Get HttpWebResponse from GET request
                string responseContent = string.Empty;
                using (HttpWebResponse httpResponse = request.GetResponse() as System.Net.HttpWebResponse)
                {
                    //Get StreamReader that holds the response stream
                    using (StreamReader reader = new System.IO.StreamReader(httpResponse.GetResponseStream()))
                    {
                        responseContent = reader.ReadToEnd();
                    }
                }

                result = JsonConvert.DeserializeObject<Tiles>(responseContent);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return result;
        }

        private Reports GetReports()
        {

            Reports result = null;
            try
            {
                HttpWebRequest request = System.Net.WebRequest.Create(String.Format("{0}/reports", datasetsUri)) as System.Net.HttpWebRequest;
                request.KeepAlive = true;
                request.Method = "GET";
                request.ContentLength = 0;
                request.ContentType = "application/json";
                request.Headers.Add("Authorization", String.Format("Bearer {0}", authResult.AccessToken));

                //Get HttpWebResponse from GET request
                string responseContent = string.Empty;
                using (HttpWebResponse httpResponse = request.GetResponse() as System.Net.HttpWebResponse)
                {
                    //Get StreamReader that holds the response stream
                    using (StreamReader reader = new System.IO.StreamReader(httpResponse.GetResponseStream()))
                    {
                        responseContent = reader.ReadToEnd();
                    }
                }

                result = JsonConvert.DeserializeObject<Reports>(responseContent);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return result;
        }
    }
}