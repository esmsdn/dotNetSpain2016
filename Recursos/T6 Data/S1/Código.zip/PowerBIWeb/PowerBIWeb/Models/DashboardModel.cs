﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PowerBIWeb.Models
{
    public class DashboardModel
    {
        public class TileModel
        {
            public string Id { get; set; }
            public string Title { get; set; }
            public string EmbedUrl { get; set; }
        }

        public class ReportModel
        {
            public string Id { get; set; }
            public string Title { get; set; }
            public string EmbedUrl { get; set; }
            public string WebUrl { get; set; }
        }

        public string AccessToken { get; set; }
        public TileModel Tile { get; set; }
        public ReportModel Report { get; set; }
    }
}