﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PowerBI.Entities
{
    public class Datasets
    {
        public Dataset[] value { get; set; }
    }

    public class Dataset
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }

    public class NewDataset
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "tables")]
        public Table[] tables { get; set; }
    }

    public class Tables
    {
        public Table[] value { get; set; }
    }

    
    public class Column
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }
        
        [JsonProperty(PropertyName = "dataType")]
        public string DataType { get; set; }
    }

    public class Table
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "columns")]
        public Column[] columns { get; set; }
    }

    public class Groups
    {
        public Group[] value { get; set; }
    }

    public class Group
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }

    public class Dashboards
    {
        public Dashboard[] value { get; set; }
    }
    public class Dashboard
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }
        [JsonProperty(PropertyName = "displayName")]
        public string Title { get; set; }
        [JsonProperty(PropertyName = "isReadOnly")]
        public bool IsReadOnly { get; set; }
    }
    public class Reports
    {
        public Report[] value { get; set; }
    }
    public class Report
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        // the name of this property will change to 'displayName' when the API moves from Beta to V1 namespace
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }
        [JsonProperty(PropertyName = "webUrl")]
        public string WebUrl { get; set; }
        [JsonProperty(PropertyName = "embedUrl")]
        public string EmbedUrl { get; set; }
    }


    public class Tiles
    {
        public Tile[] value { get; set; }
    }
    public class Tile
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }
        [JsonProperty(PropertyName = "title")]
        public string Title { get; set; }
        [JsonProperty(PropertyName = "subTitle")]
        public string Subtitle { get; set; }
        [JsonProperty(PropertyName = "embedUrl")]
        public string EmbedUrl { get; set; }
    }

}
