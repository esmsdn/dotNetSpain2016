﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.ServiceBus.Messaging;
using Newtonsoft.Json;

namespace EventHubSimulate
{
    class Program
    {
        // Completa el eventhubname y la connectionstring
        static string eventHubName = "";
        static string connectionString = "";

        static void Main(string[] args)
        {
            Console.WriteLine("Press Ctrl-C to stop the sender process");
            Console.WriteLine("Press Enter to start now");
            Console.ReadLine();
            SendingRandomMessages();
        }

        static void SendingRandomMessages()
        {
            // Install-Package WindowsAzure.ServiceBus
            var eventHubClient = EventHubClient.CreateFromConnectionString(connectionString, eventHubName);
            Random r = new Random();
            while (true)
            {
                try
                {
                    var message = new SoundMessage() {
                        Id = Guid.NewGuid().ToString(),
                        Db = r.Next(0, 100),
                        Updated =DateTime.Now
                    };

                    var serializedString = JsonConvert.SerializeObject(message);
                    Console.WriteLine("{0} > Sending message: {1}", DateTime.Now, message.Db);
                    eventHubClient.Send(new EventData(Encoding.UTF8.GetBytes(serializedString)));
                }
                catch (Exception exception)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("{0} > Exception: {1}", DateTime.Now, exception.Message);
                    Console.ResetColor();
                }

                Thread.Sleep(200);
            }
        }
    }
}
