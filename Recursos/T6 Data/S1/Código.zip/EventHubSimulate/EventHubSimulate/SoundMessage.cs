﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHubSimulate
{
    public class SoundMessage
    {
        public string Id { get; set; }
        public int Db { get; set; }
        public DateTime Updated { get; set; }
    }
}
